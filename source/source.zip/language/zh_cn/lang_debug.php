<?php

$lang = array(
	'process' => '流程',
	'_G' => '$_G',
	'trace' => 'TRACE',
	'sql' => 'SQL',
	'error' => '错误',
	'files' => '文件',
	'template' => '模板',
	'mapping' => '映射',
	'base' => '基本',
	'base_request' => '请求信息: {str}',
	'base_runtime' => '运行时间: {str}s',
	'base_throughput' => '吞 吐 率: {str}req/s',
	'base_mem' => '内存开销: {str}',
	'base_sql' => '查询次数: {str}',
	'base_files' => '文件加载: {str}',
	'base_cache' => '缓存信息: {get} get(s), {set} write(s), {delete} delete(s)',
	'base_session' => '会话信息: SESSION_ID={str}',
);