<?php

require_once './source/framework.php';

/*$actions = array('logging', 'main', 'admin', 'api', 'seccode');//允许的ACTION

$action = isset($_GET['action']) ? strtolower(trim($_GET['action'])) : $actions[0];
$operation = isset($_GET['operation']) ? strtolower(trim($_GET['operation'])) : '';

!in_array($action, $actions, true) && $action = $actions[0];
*/