<?php
$_CACHE['settings'] = array (
  'accessemail' => '',
  'censoremail' => '',
  'censorusername' => '',
  'dateformat' => 'y-n-j',
  'doublee' => '1',
  'nextnotetime' => '0',
  'timeoffset' => '28800',
  'pmlimit1day' => '100',
  'pmfloodctrl' => '15',
  'pmcenter' => '1',
  'sendpmseccode' => '1',
  'pmsendregdays' => '0',
  'maildefault' => 'gwc0721@qq.com',
  'mailsend' => '2',
  'mailserver' => 'smtp.qq.com',
  'mailport' => '25',
  'mailauth' => '1',
  'mailfrom' => 'gwc0721@qq.com',
  'mailauth_username' => 'gwc0721',
  'mailauth_password' => 'xsszxgGWC',
  'maildelimiter' => '1',
  'mailusername' => '1',
  'mailsilent' => '1',
  'version' => '1.6.0',
  'credits' => 'a:3:{i:1;a:2:{i:1;a:2:{i:0;s:4:"����";i:1;s:0:"";}i:2;a:2:{i:0;s:4:"��Ǯ";i:1;s:0:"";}}i:2;a:1:{i:1;a:2:{i:0;s:4:"����";i:1;s:2:"��";}}i:4;s:1:"
";}',
  'privatepmthreadlimit' => '25',
  'chatpmthreadlimit' => '30',
  'chatpmmemberlimit' => '35',
);

?>