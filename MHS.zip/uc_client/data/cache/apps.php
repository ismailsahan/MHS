<?php
$_CACHE['apps'] = array (
  1 => 
  array (
    'appid' => '1',
    'type' => 'DISCUZ',
    'name' => '������̳',
    'url' => 'http://192.168.1.100/bbs',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'dbcharset' => 'gbk',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
 <item id="template"><![CDATA[<a href="{url}" target="_blank">{subject}</a>]]></item>
 <item id="fields">
 <item id="subject"><![CDATA[����]]></item>
 <item id="uid"><![CDATA[�û� ID]]></item>
 <item id="username"><![CDATA[������]]></item>
 <item id="dateline"><![CDATA[����]]></item>
 <item id="url"><![CDATA[�����ַ]]></item>
 </item>
</root>',
    'allowips' => '',
  ),
  2 => 
  array (
    'appid' => '2',
    'type' => 'UCHOME',
    'name' => '���˼�԰',
    'url' => 'http://192.168.1.100/home',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'dbcharset' => 'gbk',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
 <item id="template"><![CDATA[<a href="{url}" target="_blank">{subject}</a>]]></item>
 <item id="fields">
 <item id="subject"><![CDATA[��־����]]></item>
 <item id="uid"><![CDATA[�û� ID]]></item>
 <item id="username"><![CDATA[�û���]]></item>
 <item id="dateline"><![CDATA[����]]></item>
 <item id="spaceurl"><![CDATA[�ռ��ַ]]></item>
 <item id="url"><![CDATA[��־��ַ]]></item>
 </item>
</root>',
    'allowips' => '',
  ),
  3 => 
  array (
    'appid' => '3',
    'type' => 'OTHER',
    'name' => 'Flexsns-Sky-Home',
    'url' => 'http://192.168.1.100/home/sky',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'utf-8',
    'dbcharset' => 'utf-8',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
 <item id="template"><![CDATA[{content}]]></item>
 <item id="fields">
 <item id="content"><![CDATA[[the content user posted]]]></item>
 <item id="contentLink"><![CDATA[[the content link]]]></item>
 </item>
</root>',
    'allowips' => '',
  ),
  4 => 
  array (
    'appid' => '4',
    'type' => 'OTHER',
    'name' => '���콻��',
    'url' => 'http://192.168.1.100/chat',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'dbcharset' => '',
    'synlogin' => '1',
    'recvnote' => '0',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
 <item id="template"><![CDATA[]]></item>
</root>',
    'allowips' => '',
  ),
  5 => 
  array (
    'appid' => '5',
    'type' => 'OTHER',
    'name' => '���ֲ���������ƽ̨',
    'url' => 'http://192.168.1.100/music',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'dbcharset' => '',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[<a href="{url}" target="_blank">{subject}</a>]]></item>
</root>',
    'allowips' => '',
  ),
  6 => 
  array (
    'appid' => '6',
    'type' => 'DISCUZX',
    'name' => '��������',
    'url' => 'http://192.168.1.100/site',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'dbcharset' => 'gbk',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[<a href="{url}" target="_blank">{subject}</a>]]></item>
	<item id="fields">
		<item id="subject"><![CDATA[����]]></item>
		<item id="uid"><![CDATA[�û� ID]]></item>
		<item id="username"><![CDATA[������]]></item>
		<item id="dateline"><![CDATA[����]]></item>
		<item id="url"><![CDATA[�����ַ]]></item>
	</item>
</root>',
    'allowips' => '',
  ),
  7 => 
  array (
    'appid' => '7',
    'type' => 'BRAND',
    'name' => 'Ʒ�ƿռ�',
    'url' => 'http://192.168.1.100/brand',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => 'gbk',
    'dbcharset' => 'gbk',
    'synlogin' => '1',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[<a href="{url}" target="_blank">{subject}</a>]]></item>
	<item id="fields">
		<item id="subject"><![CDATA[]]></item>
		<item id="uid"><![CDATA[]]></item>
		<item id="username"><![CDATA[]]></item>
		<item id="dateline"><![CDATA[]]></item>
		<item id="url"><![CDATA[]]></item>
	</item>
</root>',
    'allowips' => '',
  ),
  8 => 
  array (
    'appid' => '8',
    'type' => 'OTHER',
    'name' => 'NOT DEFINED',
    'url' => 'http://192.168.1.100/words',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'dbcharset' => '',
    'synlogin' => '0',
    'recvnote' => '1',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[]]></item>
</root>',
    'allowips' => '',
  ),
  9 => 
  array (
    'appid' => '9',
    'type' => 'OTHER',
    'name' => 'QW Index',
    'url' => 'http://192.168.1.100/qv/index',
    'ip' => '',
    'viewprourl' => '',
    'apifilename' => 'uc.php',
    'charset' => '',
    'dbcharset' => '',
    'synlogin' => '0',
    'recvnote' => '0',
    'extra' => false,
    'tagtemplates' => '<?xml version="1.0" encoding="ISO-8859-1"?>
<root>
	<item id="template"><![CDATA[]]></item>
</root>',
    'allowips' => '',
  ),
);

?>